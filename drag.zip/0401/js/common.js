
//index.js
$(document).ready(function(){
    //메뉴클릭시 왼쪽 헤더 토글처리
    $('#fix-menu').click(function(){
        $('#left_fix_bar').toggleClass('h-active');
        if($('#left_fix_bar').hasClass('h-active')){
            $('#left_fix_bar').animate({left: '-12.5%'});
            $('#body_wrap').animate({width: '100%'});
        }else{
            $('#left_fix_bar').animate({left: 0});
            $('#body_wrap').animate({width: '87.5%'});

        }
    });

    //LNB : 메뉴 클릭시 2,3단메뉴 슬라이드 기능
    $('#lnb .depth-1 > li > a').click(function(){
        if($(this).parent('li').children('ul').hasClass('depth-2')){
            $(this).parent('li').toggleClass('up-bg');
        }
        $(this).parent('li').children('.depth-2').stop().slideToggle();
    });
    
    $('#lnb .depth-2 > li > a').click(function(){
        if($(this).parent('li').children('ul').hasClass('depth-3')){
            $(this).parent('li').toggleClass('up-bg');
        }
        $(this).parent('li').children('.depth-3').stop().slideToggle();
    });
    
    $('#lnb .depth-2').parents('li').addClass('down-bg');
    $('#lnb .depth-3').parents('li').addClass('down-bg');

    //LNB : 세로사이즈 자동 스크롤 조절 처리
    var Left_bar_H = $('#left_fix_bar').height();
    var Header_H = $('#left_fix_bar .header').height();
    var LNB_H = Left_bar_H - Header_H;

    $('#lnb').css('height', LNB_H + 'px');

    $('#lnb .current').parents('ul').show();
    if($('#lnb .current').parent('li').parent('ul').parent('li').parent('ul').hasClass('depth-2')){
        $('#lnb .current').parent('li').parent('ul').parents('li').addClass('up-bg');
        
    }
    
    $(window).resize(function(){
        var Left_bar_H = $('#left_fix_bar').height();
        var Header_H = $('#left_fix_bar .header').height();
        var LNB_H = Left_bar_H - Header_H;
    
        $('#lnb').css('height', LNB_H + 'px');

    });


    //탭 메뉴 1개이상일시 css추가작업
    if($('.tab_container > li').length > 1){
        $('.tab_container > li:last-child').addClass('last');        
    }


    //셀렉트박스 선택시 슬라이드 토글기능
    $('.select_box_container > li > a').click(function(){
        $(this).toggleClass('on');
        $(this).parent().children('.select_box_container > li .select_list').stop().slideToggle('fast');
    });
    //셀렉트박스 내용선택시 최상단창에 텍스트 값 변환
    $('.select_list > li > a').click(function(){        
        var clickText = $(this).text();

        $(this).parent('li').parent('ul').children('li').removeClass('check');
        $(this).parent('li').addClass('check');
        $(this).parents('.select_list').stop().slideUp('fast');
        $(this).parent('li').parent('ul').parent('li').children('a').removeClass('on');
        $(this).parent('li').parent('ul').parent('li').children('a').text(clickText);
    });

    //Pop_up
    $('#shadow_bg').click(function(){
        $(this).stop().fadeOut()
        $('#wrap').removeClass('blur');
        $('.recommd_parameter_pop').stop().fadeOut();
        $('.recommd_weight_pop').stop().fadeOut();
    });

});


