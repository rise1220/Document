
//index.js
$(document).ready(function(){

    
});


